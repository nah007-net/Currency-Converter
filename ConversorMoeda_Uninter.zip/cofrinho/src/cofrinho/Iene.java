package cofrinho;

import java.util.Objects;

/**
 * CLASSE IENE - Representa a moeda Japonesa (JPY)
 * 
 * Herda de Moeda e implementa conversão para Real. Características: - Cotação
 * fixa 0.035 (exemplo: 1 JPY = 0.035 BRL) - Converte Ienes para Reais
 * multiplicando pela cotação - Valor pequeno da cotação reflete que 1 Iene vale
 * poucos centavos de Real
 */

public class Iene extends Moeda {
	private final double cotacao = 0.035; // Taxa de câmbio (constante)

	public Iene(double valor) {
		this.valor = valor;
	}

	@Override
	public int hashCode() {
		return Objects.hash(valor);
	}

	@Override
	public double converter() {
		return cotacao * valor;

	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Iene other = (Iene) obj;
		return Double.doubleToLongBits(valor) == Double.doubleToLongBits(other.valor);
	}

	@Override
	public String info() {
		return "Iene - " + valor;
	}

	@Override
	public String toString() {
		return "Iene - " + valor;
	}

}
