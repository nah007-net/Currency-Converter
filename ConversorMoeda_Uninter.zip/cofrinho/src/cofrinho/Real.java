package cofrinho;

import java.util.Objects;

/**
 * CLASSE REAL - Representa a moeda Brasileira (BRL)
 * 
 * Herda de Moeda e implementa comportamentos específicos do Real.
 * Características: - Cotação fixa 1.0 (moeda de referência) - Não precisa de
 * conversão para Real
 */

public class Real extends Moeda {
	private final double cotacao = 1; // Taxa de câmbio (constante)

	public Real(double valor) {
		this.valor = valor;
	}

	@Override
	public double converter() {
		return cotacao * valor;

	}

	@Override
	public String info() {
		return "Real - " + valor;
	}

	@Override
	public String toString() {
		return "Real - " + valor;
	}

	@Override
	public int hashCode() {
		return Objects.hash(valor);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Real other = (Real) obj;
		return Double.doubleToLongBits(valor) == Double.doubleToLongBits(other.valor);
	}

}
