package cofrinho;

import java.util.Objects;

/**
 * CLASSE DÓLAR - Representa a moeda Americana (USD)
 * 
 * Herda de Moeda e implementa conversão para Real. Características: - Cotação
 * fixa 5.4 (exemplo: 1 USD = 5.4 BRL) - Converte Dólares para Reais
 * multiplicando pela cotação
 */

public class Dolar extends Moeda {
	private final double cotacao = 5.4; // Taxa de câmbio (constante)

	public Dolar(double valor) {
		this.valor = valor;
	}

	@Override
	public int hashCode() {
		return Objects.hash(valor);
	}

	@Override
	public double converter() {
		return cotacao * valor;

	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Dolar other = (Dolar) obj;
		return Double.doubleToLongBits(valor) == Double.doubleToLongBits(other.valor);
	}

	@Override
	public String info() {
		return "Dolar - " + valor;
	}

	@Override
	public String toString() {
		return "Dolar - " + valor;
	}

}
