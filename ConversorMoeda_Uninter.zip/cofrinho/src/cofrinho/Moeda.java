package cofrinho;

/**
 * CLASSE ABSTRATA MOEDA - CLASSE BASE PARA TODAS AS MOEDAS
 * 
 * Define a interface comum para todas as moedas do sistema. Utiliza o conceito
 * de Herança para criar hierarquia de tipos.
 */

public abstract class Moeda {

	protected double valor;

	public abstract String info();

	public abstract double converter();

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}
}
