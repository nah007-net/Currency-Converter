package cofrinho;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * CLASSE PRINCIPAL - GERENCIADOR DO COFRINHO
 * 
 * Esta classe contém o método main e é responsável por: - Exibir o menu
 * interativo - Capturar entradas do usuário - Gerenciar o fluxo do programa -
 * Coordenar operações no cofrinho
 */
public class Principal {

	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);
		int opcao;

		Cofrinho cofrinho = new Cofrinho();

		while (true) {

			System.out.println("Menu");
			System.out.println("1-Adicionar moeda");
			System.out.println("2-Remover moeda");
			System.out.println("3-Listar moedas");
			System.out.println("4-Calcular total convertido para real");
			System.out.println("0-Encerrar");

			// TRATAMENTO DE ENTRADA - evita erros de tipo

			try {
				opcao = teclado.nextInt();
				teclado.nextLine(); // Consumir a quebra de linha
			} catch (InputMismatchException e) {
				System.out.println("Opção inválida. Digite um número inteiro.");
				teclado.next(); // Limpar o buffer do Scanner
				continue; // Volta para o início do loop
			}
			if (opcao == 0) {
				System.out.println("Final do programa");
				break;
			}

			int opcMoeda;
			double vlr;
			Moeda moedaSelecionada;
			switch (opcao) {

			case 1:

				// Seleção do tipo de moeda (validação de entrada)
				opcMoeda = 0;
				while (opcMoeda > 4 || opcMoeda <= 0) {
					System.out.println("1-Real");
					System.out.println("2-Dolar");
					System.out.println("3-Euro");
					System.out.println("4-Iene");
					try {
						opcMoeda = teclado.nextInt();
						teclado.nextLine(); // Consumir a quebra de linha
					} catch (InputMismatchException e) {
						System.out.println("Opção inválida. Digite um número inteiro.");
						teclado.nextLine();
						opcMoeda = 0;
						continue;
					}
				}

				// Captura do valor da moeda

				try {
					System.out.print("Digite o valor: ");
					vlr = teclado.nextDouble();
					teclado.nextLine();
				} catch (InputMismatchException e) {
					System.out.println("Valor inválido. Digite um número válido.");
					teclado.nextLine();
					continue;
				}
				moedaSelecionada = null;
				if (opcMoeda == 1) {
					moedaSelecionada = new Real(vlr);
				} else if (opcMoeda == 2) {
					moedaSelecionada = new Dolar(vlr);
				} else if (opcMoeda == 3) {
					moedaSelecionada = new Euro(vlr);
				} else if (opcMoeda == 4) {
					moedaSelecionada = new Iene(vlr);
				}
				cofrinho.adicionar(moedaSelecionada);

				break;
			case 2:

				// Código similar ao case 1 para selecionar tipo e valor

				opcMoeda = 0;
				while (opcMoeda > 4 || opcMoeda <= 0) {
					System.out.println("1-Real");
					System.out.println("2-Dolar");
					System.out.println("3-Euro");
					System.out.println("4-Iene");
					try {
						opcMoeda = teclado.nextInt();
						teclado.nextLine();
					} catch (InputMismatchException e) {
						System.out.println("Opção inválida. Digite um número inteiro.");
						teclado.nextLine();
						opcMoeda = 0;
						continue;
					}
				}

				try {
					System.out.print("Digite o valor: ");
					vlr = teclado.nextDouble();
					teclado.nextLine();
				} catch (InputMismatchException e) {
					System.out.println("Valor inválido. Digite um número válido.");
					teclado.nextLine();
					continue;
				}

				moedaSelecionada = null;
				if (opcMoeda == 1) {
					moedaSelecionada = new Real(vlr);
				} else if (opcMoeda == 2) {
					moedaSelecionada = new Dolar(vlr);
				} else if (opcMoeda == 3) {
					moedaSelecionada = new Euro(vlr);
				} else if (opcMoeda == 4) {
					moedaSelecionada = new Iene(vlr);
				}
				cofrinho.remover(moedaSelecionada);

				break;
			case 3:
				cofrinho.listagemMoedas();
				break;

			case 4:
				cofrinho.totalConvertido();
				break;

			default:
				System.out.println("Opção invalida!");
			}

		}
		teclado.close();

	}
}
