package cofrinho;

import java.util.ArrayList;

/**
 * CLASSE COFRINHO - GERENCIADOR DE COLEÇÃO DE MOEDAS
 * 
 * Responsável por armazenar e gerenciar uma coleção de objetos Moeda.
 * Implementa as operações básicas de um cofrinho virtual.
 */

public class Cofrinho {

	ArrayList<Moeda> listaMoeda = new ArrayList<Moeda>();

	public void adicionar(Moeda c) {
		listaMoeda.add(c);
	}

	public void remover(Moeda c) {
		if (listaMoeda.remove(c)) {
			System.out.println("Moeda removida com sucesso.");
		} else {
			System.out.println("Moeda não encontrada na lista.");
		}

	}

	public void listagemMoedas() {

		for (Moeda c : listaMoeda) {
			System.out.println(c.toString());
		}
	}

	public void totalConvertido() {
		double soma = 0;
		for (Moeda c : listaMoeda) {
			soma += c.converter();
		}
		System.out.printf("O total convertido para real: %.2f%n", soma);
	}

}
