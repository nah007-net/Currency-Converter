package cofrinho;

import java.util.Objects;

/**
 * CLASSE EURO - Representa a moeda Europeia (EUR)
 * 
 * Herda de Moeda e implementa conversão para Real. Características: - Cotação
 * fixa 6.2 (exemplo: 1 EUR = 6.2 BRL) - Converte Euros para Reais multiplicando
 * pela cotação
 */

public class Euro extends Moeda {
	private final double cotacao = 6.2; // Taxa de câmbio (constante)

	public Euro(double valor) {
		this.valor = valor;
	}

	@Override
	public double converter() {
		return cotacao * valor;

	}

	@Override
	public int hashCode() {
		return Objects.hash(valor);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Euro other = (Euro) obj;
		return Double.doubleToLongBits(valor) == Double.doubleToLongBits(other.valor);
	}

	@Override
	public String info() {
		return "Euro - " + valor;

	}

	@Override
	public String toString() {
		return "Euro - " + valor;
	}

}
